#!/usr/bin/env bash
# Build (or update) the updatedash LXC from your own git repository.
# Run on the Proxmox VE host as root:
#
#   REPO_URL=https://git.example.com/you/homelab.git \
#     bash -c "$(curl -fsSL https://git.example.com/you/homelab/raw/branch/main/ct/updatedash.sh)"
#
# REPO_URL may be an https/ssh git URL, or a path to a git repo on this Proxmox host.
# Re-run with CTID=<existing id> to pull the latest code into an existing container.
#
# Optional environment variables (defaults in brackets):
#   REPO_URL      git URL or local path (prompted if unset)
#   BRANCH        [main]            SUBDIR   folder in the repo holding install.sh [updatedash]
#   GIT_TOKEN     token for a private https repo   GIT_USER [git]   (sent as HTTP basic auth)
#   CTID          [next free id]    CT_HOSTNAME [updatedash]
#   CORES [1]  RAM [256]  DISK [2] (GB)  BRIDGE [vmbr0]
#   IP [dhcp] or e.g. 10.10.56.50/24      GW  (required with a static IP)
#   STORAGE / TEMPLATE_STORAGE  [first active rootdir / vztmpl storage]
#   PVE_HOST      address of this host as seen by the container [auto]
#   ALLOW_CTIDS   space-separated CT IDs the dashboard may manage [prompted]
#   GATE_USER     [updatedash-gate] unprivileged host account the dashboard's key logs in as. It can only run the
#                 gate through sudo; the dashboard no longer holds a root login on this host. GATE_USER=root keeps
#                 the old behaviour (not recommended).
#   ASSUME_YES=1  don't ask before changing host files
#   SETUP_GATE=1  with CTID=<existing>: also (re)do the host-side gate setup
#   GUI_MANAGE    [1] let the dashboard add/remove CT IDs from its web UI. 0 turns that off and
#                 removes /etc/updatedash-gate.manage (the allow list is then edited by hand only).
#   PROTECTED_CTIDS  CT IDs the dashboard may NEVER add or remove, even with GUI_MANAGE=1
#                 (e.g. Tailscale, password manager, reverse proxies). Written to
#                 /etc/updatedash-gate.protected; they can only be changed by editing the allow file by hand.
set -Eeuo pipefail
trap 'printf "\033[1;31mxx\033[0m failed on line %s\n" "$LINENO" >&2' ERR

msg()  { printf '\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; exit 1; }
tty_ok() { [ -t 0 ] && [ -t 1 ]; }

[ "$(id -u)" = 0 ] || die "Run as root on the Proxmox host."
command -v pct >/dev/null && command -v pveam >/dev/null || die "This script must run on a Proxmox VE host."

REPO_URL="${REPO_URL:-}"; BRANCH="${BRANCH:-main}"; SUBDIR="${SUBDIR-updatedash}"
GIT_TOKEN="${GIT_TOKEN:-}"; GIT_USER="${GIT_USER:-git}"
CTID="${CTID:-}"; CT_HOSTNAME="${CT_HOSTNAME:-updatedash}"
CORES="${CORES:-1}"; RAM="${RAM:-256}"; DISK="${DISK:-2}"; BRIDGE="${BRIDGE:-vmbr0}"
IP="${IP:-dhcp}"; GW="${GW:-}"
STORAGE="${STORAGE:-}"; TEMPLATE_STORAGE="${TEMPLATE_STORAGE:-}"
PVE_HOST="${PVE_HOST:-}"; ALLOW_CTIDS="${ALLOW_CTIDS:-}"; ASSUME_YES="${ASSUME_YES:-0}"; SETUP_GATE="${SETUP_GATE:-0}"
GUI_MANAGE="${GUI_MANAGE:-1}"; PROTECTED_CTIDS="${PROTECTED_CTIDS-__unset__}"
SRC_DIR=/root/updatedash-src
GATE_BIN="${GATE_BIN:-/usr/local/sbin/updatedash-gate}"
ALLOW_FILE="${ALLOW_FILE:-/etc/updatedash-gate.allow}"
GATE_USER="${GATE_USER:-updatedash-gate}"
[[ "$GATE_USER" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]] || die "Unsafe GATE_USER value."
if [ "$GATE_USER" = root ]; then GATE_HOME=/root; else GATE_HOME="/var/lib/$GATE_USER"; fi
AUTH_KEYS="${AUTH_KEYS:-$GATE_HOME/.ssh/authorized_keys}"
SUDOERS_FILE="${SUDOERS_FILE:-/etc/sudoers.d/updatedash-gate}"
MANAGE_FLAG="${MANAGE_FLAG:-/etc/updatedash-gate.manage}"
PROTECTED_FILE="${PROTECTED_FILE:-/etc/updatedash-gate.protected}"
COMMANDS_FILE="${COMMANDS_FILE:-/etc/updatedash-gate.commands}"

if [ -z "$REPO_URL" ]; then
  tty_ok || die "Set REPO_URL (git URL or a local repo path on this host)."
  read -rp "Git repository URL or local path: " REPO_URL
fi
[ -n "$REPO_URL" ] || die "REPO_URL is empty."
[[ "$BRANCH" =~ ^[A-Za-z0-9._/-]+$ ]] || die "Unsafe BRANCH value."
[[ "$SUBDIR" =~ ^[A-Za-z0-9._/-]*$ ]] || die "Unsafe SUBDIR value."

# ---------------------------------------------------------------- create the container
create_container() {
  [ -n "$CTID" ] || CTID="$(pvesh get /cluster/nextid)"
  [ -n "$STORAGE" ] || STORAGE="$(pvesm status --content rootdir | awk 'NR>1 && $3=="active" {print $1; exit}')"
  [ -n "$TEMPLATE_STORAGE" ] || TEMPLATE_STORAGE="$(pvesm status --content vztmpl | awk 'NR>1 && $3=="active" {print $1; exit}')"
  [ -n "$STORAGE" ] && [ -n "$TEMPLATE_STORAGE" ] || die "Could not find storage; set STORAGE and TEMPLATE_STORAGE."

  msg "Looking for a Debian 13 template"
  pveam update >/dev/null 2>&1 || warn "pveam update failed; using the cached template list"
  local tpl arch
  case "$(dpkg --print-architecture)" in
    amd64) arch=amd64 ;;
    arm64) arch=arm64 ;;
    *) die "Unsupported host architecture: $(dpkg --print-architecture)" ;;
  esac
  tpl="$(pveam available --section system | awk -v a="$arch" '$2 ~ ("^debian-13-standard_.*_" a "\\.tar") {print $2}' | sort -V | tail -1)"
  [ -n "$tpl" ] || die "No debian-13-standard ($arch) template found. Try: pveam update"
  pveam list "$TEMPLATE_STORAGE" | grep -qF "$tpl" || { msg "Downloading $tpl"; pveam download "$TEMPLATE_STORAGE" "$tpl"; }

  local net="name=eth0,bridge=${BRIDGE}"
  if [ "$IP" = dhcp ]; then net+=",ip=dhcp"; else
    [ -n "$GW" ] || die "A static IP needs GW=<gateway>."
    net+=",ip=${IP},gw=${GW}"
  fi

  msg "Creating CT $CTID ($CT_HOSTNAME) on $STORAGE"
  pct create "$CTID" "${TEMPLATE_STORAGE}:vztmpl/${tpl}" \
    --hostname "$CT_HOSTNAME" --unprivileged 1 --onboot 1 --tags updatedash \
    --cores "$CORES" --memory "$RAM" --swap 0 --rootfs "${STORAGE}:${DISK}" \
    --net0 "$net" --features nesting=1 --start 1

  msg "Waiting for the container network"
  for _ in $(seq 1 40); do
    pct exec "$CTID" -- getent hosts deb.debian.org >/dev/null 2>&1 && return 0
    sleep 2
  done
  die "CT $CTID has no network/DNS after 80s. Check BRIDGE, IP/GW and DNS. To start over: pct stop $CTID; pct destroy $CTID --purge"
}

# ---------------------------------------------------------------- get the code in
fetch_source() {
  pct exec "$CTID" -- rm -rf "$SRC_DIR"
  if [ -d "$REPO_URL" ]; then
    command -v git >/dev/null || die "git is needed on the host to use a local repo path."
    msg "Packing $REPO_URL @ $BRANCH from this host"
    local tmp; tmp="$(mktemp)"
    git -C "$REPO_URL" archive --format=tar.gz -o "$tmp" "$BRANCH"
    pct push "$CTID" "$tmp" /root/src.tar.gz
    rm -f "$tmp"
    pct exec "$CTID" -- sh -c "mkdir -p '$SRC_DIR' && tar xzf /root/src.tar.gz -C '$SRC_DIR' && rm -f /root/src.tar.gz"
  else
    msg "Cloning $REPO_URL @ $BRANCH inside the container"
    pct exec "$CTID" -- sh -c 'command -v git >/dev/null || { apt-get update -qq && apt-get install -y -qq --no-install-recommends git ca-certificates >/dev/null; }'
    local gitcmd=(git)
    if [ -n "$GIT_TOKEN" ]; then
      gitcmd+=(-c "http.extraHeader=Authorization: Basic $(printf '%s:%s' "$GIT_USER" "$GIT_TOKEN" | base64 -w0)")
    fi
    pct exec "$CTID" -- "${gitcmd[@]}" clone --quiet --depth 1 --branch "$BRANCH" "$REPO_URL" "$SRC_DIR"
  fi
  INSTALL_DIR="$SRC_DIR${SUBDIR:+/$SUBDIR}"
  pct exec "$CTID" -- test -f "$INSTALL_DIR/install.sh" \
    || die "install.sh not found at ${SUBDIR:-<repo root>} in the repo (set SUBDIR=...)."
}

# ---------------------------------------------------------------- host-side SSH gate
setup_gate() {
  local ct_ip pub keyblob entry
  ct_ip="$(pct exec "$CTID" -- hostname -I | awk '{print $1}')"
  [ -n "$ct_ip" ] || die "Could not read the container's IP."
  pub="$(pct exec "$CTID" -- cat /etc/updatedash/id_ed25519.pub)"
  keyblob="$(awk '{print $2}' <<<"$pub")"

  if [ -z "$ALLOW_CTIDS" ] && tty_ok; then
    echo; pct list; echo
    if [ "$GUI_MANAGE" = 1 ]; then
      read -rp "CT IDs the dashboard may update (space separated; blank = add them later in the web UI): " ALLOW_CTIDS
    else
      read -rp "CT IDs the dashboard may update (space separated, e.g. 110 111 112): " ALLOW_CTIDS
    fi
  fi
  if [ "$GUI_MANAGE" = 1 ] && [ "$PROTECTED_CTIDS" = __unset__ ] && tty_ok; then
    read -rp "Protected CT IDs the web UI may never add/remove (e.g. Tailscale, Vaultwarden, proxies; blank = none): " PROTECTED_CTIDS
  fi
  [ "$PROTECTED_CTIDS" != __unset__ ] || PROTECTED_CTIDS=""
  PROTECTED_CTIDS="${PROTECTED_CTIDS//[^0-9]/ }"
  local id ids=()
  ALLOW_CTIDS="${ALLOW_CTIDS//[^0-9]/ }"   # accept "106, 114" or "106 114." etc.
  for id in $ALLOW_CTIDS; do
    [[ "$id" =~ ^[0-9]+$ ]] || die "Bad CT id: $id"
    [ "$id" != "$CTID" ] || continue
    pct status "$id" >/dev/null 2>&1 || die "CT $id does not exist."
    ids+=("$id")
  done

  if [ "$GATE_USER" = root ]; then GATE_CMD="${GATE_BIN}"; else GATE_CMD="sudo -n ${GATE_BIN}"; fi
  entry="command=\"${GATE_CMD}\",from=\"${ct_ip}\",restrict ${pub}"
  echo
  msg "About to change this Proxmox host:"
  echo "   - install ${GATE_BIN}: the key can only run pct exec/snapshot, only for the allowed CT IDs, and only"
  echo "     for a built-in list of update/check commands (extras go in ${COMMANDS_FILE}); every request is logged to syslog"
  echo "   - allow CT IDs: ${ids[*]:-<none yet>}   (${ALLOW_FILE})"
  if [ "$GUI_MANAGE" = 1 ]; then
    echo "   - turn ON web-UI management of that list (${MANAGE_FLAG}); protected IDs: ${PROTECTED_CTIDS:-<none>}"
    echo "     NOTE: with this on, anyone who gets into the dashboard can add other containers (except protected ones)."
  else
    echo "   - web-UI management of the list stays OFF (edit ${ALLOW_FILE} by hand)"
  fi
  if [ "$GATE_USER" != root ]; then
    echo "   - create the unprivileged user '${GATE_USER}' (no password, no way to sign in except this one restricted key)"
    echo "     and allow it to run ONLY ${GATE_BIN} as root through sudo (${SUDOERS_FILE})"
  fi
  echo "   - add this line to ${AUTH_KEYS}:"
  echo "     ${entry:0:150}..."
  if [ "$ASSUME_YES" != 1 ]; then
    tty_ok || { warn "Not interactive and ASSUME_YES!=1: skipping host changes. Do README step 3 by hand."; return 0; }
    read -rp "Proceed? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || { warn "Skipped host changes."; return 0; }
  fi

  pct pull "$CTID" /opt/updatedash/pve-gate.py "$GATE_BIN"
  chmod 755 "$GATE_BIN"
  touch "$ALLOW_FILE"
  for id in "${ids[@]}"; do grep -qx "$id" "$ALLOW_FILE" || echo "$id" >> "$ALLOW_FILE"; done
  if [ "$GUI_MANAGE" = 1 ]; then
    echo "$CTID" > "$MANAGE_FLAG"
    if [ -n "${PROTECTED_CTIDS// /}" ]; then
      { echo "# CT IDs the dashboard can never add or remove"; for id in $PROTECTED_CTIDS; do echo "$id"; done; } > "$PROTECTED_FILE"
    else
      : > "$PROTECTED_FILE"
    fi
  else
    rm -f "$MANAGE_FLAG"
  fi
  [ -f "$COMMANDS_FILE" ] || printf '%s\n' "# Extra commands the dashboard may run inside allowed containers, one exact command per line." \
    "# The Settings screen of the dashboard lists the ones from your config that need approval here." > "$COMMANDS_FILE"
  if [ "$GATE_USER" != root ]; then
    command -v sudo >/dev/null 2>&1 || { msg "Installing sudo (needed so '${GATE_USER}' can run the gate)"; apt-get install -y sudo >/dev/null; }
    id "$GATE_USER" >/dev/null 2>&1 || useradd --system --home-dir "$GATE_HOME" --shell /bin/sh "$GATE_USER"
    usermod -p '*' "$GATE_USER"                         # no password, but not "locked" (locked accounts can refuse key logins)
    mkdir -p "$GATE_HOME/.ssh"
    chown root:root "$GATE_HOME" "$GATE_HOME/.ssh"; chmod 755 "$GATE_HOME"; chmod 755 "$GATE_HOME/.ssh"   # root-owned: the account can't edit its own key file
    tmpsudo="$(mktemp)"
    cat > "$tmpsudo" <<SUDOERS
Defaults!${GATE_BIN} env_keep += "SSH_ORIGINAL_COMMAND SSH_CONNECTION SSH_CLIENT"
${GATE_USER} ALL=(root) NOPASSWD: ${GATE_BIN}
SUDOERS
    visudo -cf "$tmpsudo" >/dev/null || die "Generated sudoers rule did not validate; nothing was installed."
    install -m 0440 -o root -g root "$tmpsudo" "$SUDOERS_FILE"; rm -f "$tmpsudo"
  fi
  mkdir -p "$(dirname "$AUTH_KEYS")"; touch "$AUTH_KEYS"
  # add the dashboard's key, or replace an older line for the same key (so re-running upgrades its restrictions)
  tmpkeys="$(mktemp)"
  { grep -vF "$keyblob" "$AUTH_KEYS" || true; echo "$entry"; } > "$tmpkeys"
  cat "$tmpkeys" > "$AUTH_KEYS"
  rm -f "$tmpkeys"
  if [ "$GATE_USER" != root ]; then chown root:root "$AUTH_KEYS"; chmod 644 "$AUTH_KEYS"; fi
  msg "Gate installed."

  [ -n "$PVE_HOST" ] || PVE_HOST="$(ip -4 route get "$ct_ip" 2>/dev/null | grep -oP 'src \K\S+' | head -1 || true)"
  [ -n "$PVE_HOST" ] || PVE_HOST="$(hostname -I | awk '{print $1}')"
  pct exec "$CTID" -- sed -i -e "s|^  host: .*|  host: ${PVE_HOST}|" -e "s|^  user: .*|  user: ${GATE_USER}|" /etc/updatedash/config.yaml
  # Pre-trust this host's SSH key inside the dashboard, so its first connection to Proxmox can't be intercepted.
  local hostpub
  hostpub="$(awk '{print $1" "$2}' /etc/ssh/ssh_host_ed25519_key.pub 2>/dev/null || true)"
  if [ -n "$hostpub" ]; then
    pct exec "$CTID" -- sh -c "grep -qF '${PVE_HOST} ${hostpub}' /var/lib/updatedash/known_hosts 2>/dev/null || echo '${PVE_HOST} ${hostpub}' >> /var/lib/updatedash/known_hosts; chown updatedash:updatedash /var/lib/updatedash/known_hosts; chmod 600 /var/lib/updatedash/known_hosts"
  else
    warn "Could not read /etc/ssh/ssh_host_ed25519_key.pub; the dashboard will trust this host's key on first use."
  fi
  if [ "$GATE_USER" != root ]; then
    # Prove the new login works from the dashboard container BEFORE retiring the old root-owned key line.
    if pct exec "$CTID" -- runuser -u updatedash -- ssh -i /etc/updatedash/id_ed25519 -o BatchMode=yes -o IdentitiesOnly=yes \
        -o UserKnownHostsFile=/var/lib/updatedash/known_hosts -o StrictHostKeyChecking=yes "${GATE_USER}@${PVE_HOST}" "pct list" >/dev/null 2>&1; then
      msg "Login as ${GATE_USER} works."
      if [ -f /root/.ssh/authorized_keys ] && grep -qF "$keyblob" /root/.ssh/authorized_keys; then
        tmpkeys="$(mktemp)"; grep -vF "$keyblob" /root/.ssh/authorized_keys > "$tmpkeys" || true
        cat "$tmpkeys" > /root/.ssh/authorized_keys; rm -f "$tmpkeys"
        msg "Removed the dashboard's old root login from /root/.ssh/authorized_keys."
      fi
    else
      warn "Could not log in as ${GATE_USER} from the dashboard container. The old root key line (if any) was left in place."
      warn "Check: sshd AllowUsers/Match rules, 'journalctl -u ssh' on this host. To go back: GATE_USER=root SETUP_GATE=1 CTID=${CTID} ..."
    fi
  fi
  pct exec "$CTID" -- systemctl restart updatedash
  CT_IP="$ct_ip"
}

# ---------------------------------------------------------------- main
if [ -n "$CTID" ] && pct status "$CTID" >/dev/null 2>&1; then
  msg "CT $CTID exists: updating updatedash in place"
  MODE=update
else
  MODE=create
  create_container
fi

fetch_source
msg "Running install.sh inside CT $CTID"
pct exec "$CTID" -- bash "$INSTALL_DIR/install.sh"
pct exec "$CTID" -- rm -rf "$SRC_DIR"

CT_IP="$(pct exec "$CTID" -- hostname -I | awk '{print $1}')"
if [ "$MODE" = create ] || [ "$SETUP_GATE" = 1 ]; then setup_gate; fi
pct exec "$CTID" -- systemctl restart updatedash

echo
msg "Done."
SCHEME=http
pct exec "$CTID" -- grep -qE '^tls: *auto' /etc/updatedash/config.yaml 2>/dev/null && SCHEME=https
echo "   Dashboard : ${SCHEME}://${CT_IP}:8099   (CT $CTID)"
if [ "$SCHEME" = https ]; then
  echo "               self-signed certificate: your browser will warn once. In Nginx Proxy Manager use scheme https to this address."
fi
PLAIN_PW="$(pct exec "$CTID" -- awk -F'"' '/^password:/ {print $2}' /etc/updatedash/config.yaml 2>/dev/null || true)"
if [ -n "$PLAIN_PW" ]; then
  echo "   Login     : admin / $PLAIN_PW   (plaintext in the config; set a new one under Settings)"
else
  echo "   Login     : admin   (a new install prints its generated password once, above; otherwise use your existing one)"
fi
echo "   Next      : sign in, then Settings -> turn on two-factor sign-in (this tool can run commands as root)."
echo "               Edit your services in the container: pct exec $CTID -- nano /etc/updatedash/config.yaml"
echo "               then: pct exec $CTID -- systemctl restart updatedash"
